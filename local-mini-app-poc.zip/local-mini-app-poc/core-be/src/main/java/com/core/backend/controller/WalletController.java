package com.core.backend.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/wallet")
public class WalletController {

    private final Map<String, Integer> userBalances = new HashMap<>();

    public WalletController() {
        // Mock default user balance for our test user in Keycloak
        // Keycloak uses UUIDs, but we will seed a default or populate on-demand
        userBalances.put("testuser", 5000);
    }

    @PostMapping("/deduct")
    public ResponseEntity<?> deductPoints(
            @RequestHeader(value = "X-User-Id", required = false) String userId,
            @RequestHeader(value = "X-Client-Id", required = false) String clientId,
            @RequestHeader(value = "X-User-Scopes", required = false) String scopes,
            @RequestHeader(value = "X-Token-Audience", required = false) String audience,
            @RequestBody Map<String, Object> payload) {

        System.out.println("====== CORE AKS BACKEND RECEIVED CALL ======");
        System.out.println("X-User-Id    (User UUID)     : " + userId);
        System.out.println("X-Client-Id  (Calling Client): " + clientId);
        System.out.println("X-User-Scopes(Active Scopes) : " + scopes);
        System.out.println("X-Token-Audience (Intended)  : " + audience);
        System.out.println("==========================================");

        // 1. Guard check: Enforce that request came through Gateway (offloaded safety)
        if (userId == null || userId.isEmpty() || clientId == null || clientId.isEmpty()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body("Forbidden: Direct pod access without gateway header verification is blocked.");
        }

        // 2. Authorization (zero crypt overhead). Accept EITHER:
        //    - an explicit "wallet-scope" (direct/refresh-token flows), OR
        //    - an "aud" of core-wallet-service (RFC 8693 token-exchange flows, where legacy
        //      Keycloak exchange yields an empty scope claim but a resource-restricted audience).
        boolean hasWalletScope = scopes != null && scopes.contains("wallet-scope");
        boolean isAudiencedForWallet = audience != null && audience.contains("core-wallet-service");
        if (!hasWalletScope && !isAudiencedForWallet) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body("Forbidden: Missing wallet-scope required to transact.");
        }

        // 3. Process business logic (Simulated Wallet Deduction)
        int amountToDeduct = (int) payload.getOrDefault("amount", 0);
        int currentBalance = userBalances.getOrDefault(userId, 1000); // Seed 1000 if new

        if (currentBalance < amountToDeduct) {
            return ResponseEntity.badRequest().body("Insufficient funds. Current balance: " + currentBalance);
        }

        int newBalance = currentBalance - amountToDeduct;
        userBalances.put(userId, newBalance);

        return ResponseEntity.ok(Map.of(
            "status", "SUCCESS",
            "userId", userId,
            "transactingClient", clientId,
            "deductedAmount", amountToDeduct,
            "remainingBalance", newBalance,
            "message", "Wallet points deducted successfully."
        ));
    }

    @PostMapping("/credit")
    public ResponseEntity<?> creditPoints(
            @RequestHeader(value = "X-User-Id", required = false) String userId,
            @RequestHeader(value = "X-Client-Id", required = false) String clientId,
            @RequestHeader(value = "X-User-Scopes", required = false) String scopes,
            @RequestBody Map<String, Object> payload) {

        System.out.println("====== CORE AKS BACKEND RECEIVED CREDIT CALL ======");
        System.out.println("X-User-Id    (User UUID)     : " + userId);
        System.out.println("X-Client-Id  (Calling Client): " + clientId);
        System.out.println("X-User-Scopes(Active Scopes) : " + scopes);
        System.out.println("==========================================");

        // 1. Guard check: Enforce that request came through Gateway
        if (userId == null || userId.isEmpty() || clientId == null || clientId.isEmpty()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body("Forbidden: Direct pod access without gateway header verification is blocked.");
        }

        // 2. Scope verification (expects insurance-scope)
        if (scopes == null || !scopes.contains("insurance-scope")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body("Forbidden: Missing insurance-scope required to transact.");
        }

        // 3. Process business logic (Simulated Wallet Credit)
        int amountToCredit = (int) payload.getOrDefault("amount", 0);
        int currentBalance = userBalances.getOrDefault(userId, 1000); // Seed 1000 if new

        int newBalance = currentBalance + amountToCredit;
        userBalances.put(userId, newBalance);

        return ResponseEntity.ok(Map.of(
            "status", "SUCCESS",
            "userId", userId,
            "transactingClient", clientId,
            "creditedAmount", amountToCredit,
            "remainingBalance", newBalance,
            "message", "Wallet points credited successfully."
        ));
    }
}
